package com.example.halukay;

public class OrderAdapter {
}
