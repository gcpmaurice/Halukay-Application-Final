package com.example.halukay;

import android.view.View;

import java.util.ArrayList;

public interface OrderListener {
    void onOrderClick(View v, int pos);
}
